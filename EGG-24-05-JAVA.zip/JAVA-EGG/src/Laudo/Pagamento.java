package Laudo;

import java.time.LocalDate;

public class Pagamento {
    private String tipoPagamento;
    private LocalDate dataPagamento;
    private int qtdParcelas;

    public Pagamento() {
    }

    public Pagamento(String tipoPagamento, LocalDate dataPagamento, int qtdParcelas) {
        this.tipoPagamento = tipoPagamento;
        this.dataPagamento = dataPagamento;
        this.qtdParcelas = qtdParcelas;
    }

    public String getTipoPagamento() {
        return tipoPagamento;
    }

    public void setTipoPagamento(String tipoPagamento) {
        this.tipoPagamento = tipoPagamento;
    }

    public LocalDate getDataPagamento() {
        return dataPagamento;
    }

    public void setDataPagamento(LocalDate dataPagamento) {
        this.dataPagamento = dataPagamento;
    }

    public int getQtdParcelas() {
        return qtdParcelas;
    }

    public void setQtdParcelas(int qtdParcelas) {
        this.qtdParcelas = qtdParcelas;
    }

    @Override
    public String toString() {
        return "\n\n======== Pagamento ========" +
                "\nTipo de Pagamento: " + tipoPagamento +
                "\nData de Pagamento: " + dataPagamento +
                "\nQuantidade de Parcelas: " + qtdParcelas +
                super.toString();
    }
    public void realizarPagamento(){

    }
    public void parcelarPagamento(){

    }
    public void gerarComprovante(){

    }
    public void cancelarPagamento(){

    }
    public void cobrarFatura(){

    }
    public void agendarPagamento(){

    }
}
