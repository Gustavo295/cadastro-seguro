package Laudo;

public enum TIPO_PROBLEMA {
    HIDRAULICO,
    MECANICO,
    ELETRICO
}
