package Laudo;

public class Diagnostico {
    private TIPO_PROBLEMA tipoProblema;
    private String problema;
    private String solucao;
    private String Sugestao;

    public Diagnostico() {
    }

    public Diagnostico(TIPO_PROBLEMA tipoProblema, String problema, String solucao, String sugestao) {
        this.tipoProblema = tipoProblema;
        this.problema = problema;
        this.solucao = solucao;
        Sugestao = sugestao;
    }

    public TIPO_PROBLEMA getTipoProblema() {
        return tipoProblema;
    }

    public void setTipoProblema(TIPO_PROBLEMA tipoProblema) {
        this.tipoProblema = tipoProblema;
    }

    public String getProblema() {
        return problema;
    }

    public void setProblema(String problema) {
        this.problema = problema;
    }

    public String getSolucao() {
        return solucao;
    }

    public void setSolucao(String solucao) {
        this.solucao = solucao;
    }

    public String getSugestao() {
        return Sugestao;
    }

    public void setSugestao(String sugestao) {
        Sugestao = sugestao;
    }

    @Override
    public String toString() {
        return "\n\n===== Diagnostico =====" +
                "\nTipo de Problema:"  + tipoProblema +
                "\nProblema: " + problema +
                "\nSolução: " + solucao +
                "\nSugestão: " + Sugestao ;
    }
}
