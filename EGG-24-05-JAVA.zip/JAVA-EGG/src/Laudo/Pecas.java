package Laudo;

public class Pecas {
private double precoUnitario;
private int quantidadePeca;
private double precoTotalPeca;

    public Pecas() {
    }

    public Pecas(double precoUnitario, int quantidadePeca, double precoTotalPeca) {
        this.precoUnitario = precoUnitario;
        this.quantidadePeca = quantidadePeca;
        this.precoTotalPeca = precoTotalPeca;
    }

    public double getPrecoUnitario() {
        return precoUnitario;
    }

    public void setPrecoUnitario(double precoUnitario) {
        this.precoUnitario = precoUnitario;
    }

    public int getQuantidadePeca() {
        return quantidadePeca;
    }

    public void setQuantidadePeca(int quantidadePeca) {
        this.quantidadePeca = quantidadePeca;
    }

    public double getPrecoTotalPeca() {
        return precoTotalPeca;
    }

    public void setPrecoTotalPeca(double precoTotalPeca) {
        this.precoTotalPeca = precoTotalPeca;
    }

    @Override
    public String toString() {
        return "\n\n========== Pecas ==========" +
                "\nPreco de Peça Unitario: " + precoUnitario +
                "\nQuantidade de Peças: " + quantidadePeca +
                "\nPreco Total de Peças: " + precoTotalPeca ;
    }

    public void calcularPrecoTotal(){}
    public void solicitarPecas(){}
    public void removerPecas(){}
}
