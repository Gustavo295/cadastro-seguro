package Laudo;

public class Servicos {
    private String tipoServico;
    private double precoServico;

    public Servicos() {
    }

    public Servicos(String tipoServico, double precoServico) {
        this.tipoServico = tipoServico;
        this.precoServico = precoServico;
    }

    public String getTipoServico() {
        return tipoServico;
    }

    public void setTipoServico(String tipoServico) {
        this.tipoServico = tipoServico;
    }

    public double getPrecoServico() {
        return precoServico;
    }

    public void setPrecoServico(double precoServico) {
        this.precoServico = precoServico;
    }

    @Override
    public String toString() {
        return "\n======== Servicos ========" +
                "\nTipo de Serviço: " + tipoServico +
                "\nPreco do Serviço: " + precoServico;
    }
    public void agendarServico(){}
}
