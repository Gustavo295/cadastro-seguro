package Laudo;

import Perfil.Usuario;

import java.time.LocalDate;
import java.util.Date;

public class Laudo {
    private String nomeLaudo;
    private int numeroLaudo;
    private LocalDate dataEmissao;
    private Usuario usuario;
    private Diagnostico diagnostico;
    private Orcamento orcamento;
    private String declaracaoVeracidade;

    public Laudo() {
    }

    public Laudo(String nomeLaudo, int numeroLaudo, LocalDate dataEmissao, Usuario usuario, Diagnostico diagnostico, Orcamento orcamento, String declaracaoVeracidade) {
        this.nomeLaudo = nomeLaudo;
        this.numeroLaudo = numeroLaudo;
        this.dataEmissao = dataEmissao;
        this.usuario = usuario;
        this.diagnostico = diagnostico;
        this.orcamento = orcamento;
        this.declaracaoVeracidade = declaracaoVeracidade;
    }

    public String getNomeLaudo() {
        return nomeLaudo;
    }

    public void setNomeLaudo(String nomeLaudo) {
        this.nomeLaudo = nomeLaudo;
    }

    public int getNumeroLaudo() {
        return numeroLaudo;
    }

    public void setNumeroLaudo(int numeroLaudo) {
        this.numeroLaudo = numeroLaudo;
    }

    public LocalDate getDataEmissao() {
        return dataEmissao;
    }

    public void setDataEmissao(LocalDate dataEmissao) {
        this.dataEmissao = dataEmissao;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Diagnostico getDiagnostico() {
        return diagnostico;
    }

    public void setDiagnostico(Diagnostico diagnostico) {
        this.diagnostico = diagnostico;
    }

    public Orcamento getOrcamento() {
        return orcamento;
    }

    public void setOrcamento(Orcamento orcamento) {
        this.orcamento = orcamento;
    }

    public String getDeclaracaoVeracidade() {
        return declaracaoVeracidade;
    }

    public void setDeclaracaoVeracidade(String declaracaoVeracidade) {
        this.declaracaoVeracidade = declaracaoVeracidade;
    }

    @Override
    public String toString() {
        return "\n\n======= Laudo =======" +
                "\nNome do Laudo: " + nomeLaudo +
                "\nNumero do Laudo: " + numeroLaudo +
                "\nData de Emissão: " + dataEmissao +
                "\nUsuario: " + usuario +
                "\nDiagnostico: " + diagnostico +
                "\nOrçamento: " + orcamento +
                "\nDeclaracao de Veracidade: " + declaracaoVeracidade;
    }

    public void visualizarLaudo(){}
    public void calcularVencimento(){}
    public void formatarLaudo(){}
}
