package Laudo;

import java.time.LocalDate;
import java.util.ArrayList;

public class Orcamento {
    private ArrayList<Pecas> pecas;
    private ArrayList<Servicos> servicos;
    private LocalDate dataValidade;
    private double valorFinal;

    public Orcamento() {
    }

    public Orcamento(ArrayList<Pecas> pecas, ArrayList<Servicos> servicos, LocalDate dataValidade, double valorFinal) {
        this.pecas = pecas;
        this.servicos = servicos;
        this.dataValidade = dataValidade;
        this.valorFinal = valorFinal;
    }

    public ArrayList<Pecas> getPecas() {
        return pecas;
    }

    public void setPecas(ArrayList<Pecas> pecas) {
        this.pecas = pecas;
    }

    public ArrayList<Servicos> getServicos() {
        return servicos;
    }

    public void setServicos(ArrayList<Servicos> servicos) {
        this.servicos = servicos;
    }

    public LocalDate getDataValidade() {
        return dataValidade;
    }

    public void setDataValidade(LocalDate dataValidade) {
        this.dataValidade = dataValidade;
    }

    public double getValorFinal() {
        return valorFinal;
    }

    public void setValorFinal(double valorFinal) {
        this.valorFinal = valorFinal;
    }

    @Override
    public String toString() {
        return "\n\n====== Orcamento ======" +
                "\nPecas: " + pecas +
                "\nServicos: " + servicos +
                "\nData de Validade: " + dataValidade +
                "\nValorFinal: " + valorFinal;
    }

    public void calcularOrcamento(){}
}
