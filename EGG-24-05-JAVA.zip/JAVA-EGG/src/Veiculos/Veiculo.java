package Veiculos;

import java.time.LocalDate;
import java.util.Scanner;

public class Veiculo {
    protected String marca;
    protected int ano;
    protected String modelo;
    protected String placa;
    protected double quilometragem;
    protected String condicao;


    public Veiculo() {
    }

    public Veiculo(String marca, int ano, String modelo, String placa, double quilometragem, String condicao) {
        this.marca = marca;
        this.ano = ano;
        this.modelo = modelo;
        this.placa = placa;
        this.quilometragem = quilometragem;
        this.condicao = condicao;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public double getQuilometragem() {
        return quilometragem;
    }

    public void setQuilometragem(double quilometragem) {
        this.quilometragem = quilometragem;
    }

    public String getCondicao() {
        return condicao;
    }

    public void setCondicao(String condicao) {
        this.condicao = condicao;
    }

    @Override
    public String toString() {
        return "\n\n======= Veículo =======" +
                "\n Modelo: " + modelo +
                "\n Marca: " + marca  +
                "\n Ano: " + ano +
                "\n Placa: " + placa  +
                "\n Quilometragem: " + quilometragem +"km" +
                "\n Condição: " + condicao;
    }
    public void addVeiculo(){
        Scanner scan = new Scanner(System.in);
        String regex_placaAntiga = "^[A-Z]{3}-\\d{4}$";
        String regex_placaNova = "^[A-Z]{3}\\d{1}[A-Z]{1}\\d{2}$";
        System.out.println("Digite a marca do veiculo");
        marca = scan.nextLine();
        System.out.println("Digite o modelo do veículo");
        modelo = scan.nextLine();
        while (true){
            System.out.println("Digite o ano de fabricação do veículo");
            ano = scan.nextInt();
            if (ano<=1884 || ano> LocalDate.now().getYear()) {
                System.out.println("Digite um ano válido");
            }
            else{
                break;
            }
        }
        scan.nextLine();
        while(true){
            System.out.println("Digite a placa do veículo");
            placa = scan.nextLine().toUpperCase();
            if (placa.matches(regex_placaAntiga) || (placa.matches(regex_placaNova))){
                System.out.println(placa);
                break;
            }
            else {
                System.out.println("Digite uma placa válida");
            }}
        System.out.println("Digite a quilometragem total do veículo");
        quilometragem = scan.nextDouble();
        scan.nextLine();
        System.out.println("Digite a condição do veículo");
        condicao = scan.nextLine();
    }
public void mostrarVeiculo(){
        System.out.println(toString());
}
}