package Veiculos;

import Perfil.ESTADO;
import Veiculos.Veiculo.*;
import java.time.LocalDate;
import java.time.Year;
import java.util.Scanner;

public class Carro extends Veiculo {
    private String tipoMotor;
    private double velocidadeMax;
    private TIPO_CARRO tipoCarro;

    public Carro() {
    }

    public Carro(String marca, int ano, String modelo, String placa, double quilometragem, String condicao, String tipoMotor, double velocidadeMax, TIPO_CARRO tipoCarro, Veiculo veiculo) {
        super(marca, ano, modelo, placa, quilometragem, condicao);
        this.tipoMotor = tipoMotor;
        this.velocidadeMax = velocidadeMax;
        this.tipoCarro = tipoCarro;
    }

    public String getTipoMotor() {
        return tipoMotor;
    }

    public void setTipoMotor(String tipoMotor) {
        this.tipoMotor = tipoMotor;
    }

    public double getVelocidadeMax() {
        return velocidadeMax;
    }

    public void setVelocidadeMax(double velocidadeMax) {
        this.velocidadeMax = velocidadeMax;
    }

    public TIPO_CARRO getTipoCarro() {
        return tipoCarro;
    }

    public void setTipoCarro(TIPO_CARRO tipoCarro) {

        this.tipoCarro = tipoCarro;
    }

    @Override
    public String toString() {
        return
                "\n\n======= Carro =======" +
                "\n Tipo de Motor: " + tipoMotor  +
                "\n Velocidade Máxima: " + velocidadeMax + "km/h" +
                "\n Tipo de Carro: " + tipoCarro +
                "\n\n"+super.toString();

    }
    public void addCarro(){
        Scanner scan = new Scanner(System.in);
        System.out.println("Digite o tipo de Motor do veículo");
        tipoMotor = scan.nextLine();
        while(true){
        System.out.println("Digite o tipo de carro");
        String tipo = scan.nextLine().toUpperCase();
        if (TIPO_CARRO.eh_valido(tipo)) {
            tipoCarro = TIPO_CARRO.valueOf(tipo);
            break;
        }
        else {
            System.out.println("Tipo de Carro inválido, tente novamente.");
        }}
        System.out.println("Digite a velocidade máxima do veículo");
        velocidadeMax = scan.nextDouble();
        scan.nextLine();
    }

    public void visualizarCarro(){
        System.out.println(toString());
    }
}
