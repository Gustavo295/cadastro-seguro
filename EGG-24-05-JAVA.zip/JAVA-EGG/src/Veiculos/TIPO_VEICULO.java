package Veiculos;

public enum TIPO_VEICULO {
    MANUAL,
    AUTOMATICO,
    ELETRICO,
    DIESEL,
    HIBRIDO
}
