package Veiculos;

import Perfil.ESTADO;

public enum TIPO_CARRO {
    CUV,
    ESPORTIVO,
    FURGAO,
    PICKUP,
    SEDAN,
    SUV,
    HATCH,
    PERUA,
    MINIVAN,
    LUXO,
    CONVERSIVEL;
    public static boolean eh_valido(String input) {
        for (TIPO_CARRO tipoCarro: TIPO_CARRO.values()) {
            if (tipoCarro.name().equals(input)) {
                return true;
            }
        }
        return false;
    }
}
