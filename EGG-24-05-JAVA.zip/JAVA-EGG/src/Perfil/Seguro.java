package Perfil;

import java.time.LocalDate;

public class Seguro extends Usuario{
    protected int numeroApolice;
    protected String cobertura;
    protected double premio;
    protected LocalDate dataInicio;
    protected LocalDate dataValidade;
    protected VeiculoSegurado veiculo;

    public Seguro() {
    }

    public Seguro(String cpf, String username, LocalDate dataNascimento, String sexo, int numeroApolice, String cobertura, double premio, LocalDate dataInicio, LocalDate dataValidade, VeiculoSegurado veiculo) {
        super(cpf, username, dataNascimento, sexo);
        this.numeroApolice = numeroApolice;
        this.cobertura = cobertura;
        this.premio = premio;
        this.dataInicio = dataInicio;
        this.dataValidade = dataValidade;
        this.veiculo = veiculo;

    }

    public int getNumeroApolice() {
        return numeroApolice;
    }

    public void setNumeroApolice(int numeroApolice) {
        this.numeroApolice = numeroApolice;
    }

    public String getCobertura() {
        return cobertura;
    }

    public void setCobertura(String cobertura) {
        this.cobertura = cobertura;
    }

    public double getPremio() {
        return premio;
    }

    public void setPremio(double premio) {
        this.premio = premio;
    }

    public LocalDate getDataInicio() {
        return dataInicio;
    }

    public void setDataInicio(LocalDate dataInicio) {
        this.dataInicio = dataInicio;
    }

    public LocalDate getDataValidade() {
        return dataValidade;
    }

    public void setDataValidade(LocalDate dataValidade) {
        this.dataValidade = dataValidade;
    }

    public VeiculoSegurado getVeiculos() {
        return veiculo;
    }

    public void setVeiculos(VeiculoSegurado veiculo) {
        this.veiculo = veiculo;
    }

    @Override
    public String toString() {
        return "========= Seguro ==========" +
                "\nNumero da Apolice: " + numeroApolice +
                "\nCobertura: " + cobertura + '\'' +
                "\nPrêmio: " + premio +
                "\nData de Inicio: " + dataInicio +
                "\nData de Validade: " + dataValidade +
                 veiculo +super.toString();
    }
}
