package Perfil;

import Veiculos.Veiculo;

import java.time.LocalDate;

public class VeiculoSegurado {
    private String infoVeiculo;
    private String infoSeguro;
    private String coberturaSeguro;

    public VeiculoSegurado() {
    }

    public VeiculoSegurado(String infoVeiculo, String infoSeguro, String coberturaSeguro) {
        this.infoVeiculo = infoVeiculo;
        this.infoSeguro = infoSeguro;
        this.coberturaSeguro = coberturaSeguro;
    }

    public String getInfoVeiculo() {
        return infoVeiculo;
    }

    public void setInfoVeiculo(String infoVeiculo) {
        this.infoVeiculo = infoVeiculo;
    }

    public String getInfoSeguro() {
        return infoSeguro;
    }

    public void setInfoSeguro(String infoSeguro) {
        this.infoSeguro = infoSeguro;
    }

    public String getCoberturaSeguro() {
        return coberturaSeguro;
    }

    public void setCoberturaSeguro(String coberturaSeguro) {
        this.coberturaSeguro = coberturaSeguro;
    }

    @Override
    public String toString() {
        return "\n\n====== VeiculoSegurado ======" +
                "\nInformações do Veiculo: " + infoVeiculo +
                "\nInformações do Seguro: " + infoSeguro +
                "\nCobertura do Seguro: " + coberturaSeguro ;
    }
}
