package Perfil;

public enum USO_VEICULO {
    USO_PESSOAL,
    USO_COMERCIAL,
    USO_CORPORATIVO,
    USO_SERVICO,
    USO_FROTA
}
