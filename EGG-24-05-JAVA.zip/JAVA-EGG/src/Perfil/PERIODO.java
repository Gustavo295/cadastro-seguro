package Perfil;

public enum PERIODO {
    MENSAL,
    ANUAL
}
