package Perfil;

import java.time.LocalDate;

public class Usuario {
    protected String cpf;
    protected String username;
    protected LocalDate dataNascimento;
    protected String sexo;

    public Usuario() {
    }

    public Usuario(String cpf, String username, LocalDate dataNascimento, String sexo) {
        this.cpf = cpf;
        this.username = username;
        this.dataNascimento = dataNascimento;
        this.sexo = sexo;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }


    public LocalDate getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(LocalDate dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    @Override
    public String toString() {
        return "\n\n==== Informações do Usuario ====" +
                "\nCPF: " + cpf +
                "\nUsername: " + username +
                "\nData de Nascimento: " + dataNascimento +
                "\nSexo: " + sexo;
    }
}
