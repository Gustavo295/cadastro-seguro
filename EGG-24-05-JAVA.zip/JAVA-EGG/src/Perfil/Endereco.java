package Perfil;

import java.util.ArrayList;
import java.util.Scanner;

public class Endereco {
    protected String cep;
    protected String nomeLogradouro;
    protected int numeroLogradouro;
    protected ESTADO estado;
    protected String cidade;
    protected String bairro;
    protected String complemento;

    public Endereco() {
    }

    public Endereco(String cep, String nomeLogradouro, int numeroLogradouro, ESTADO estado, String cidade, String bairro, String complemento) {
        this.cep = cep;
        this.nomeLogradouro = nomeLogradouro;
        this.numeroLogradouro = numeroLogradouro;
        this.estado = estado;
        this.cidade = cidade;
        this.bairro = bairro;
        this.complemento = complemento;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getNomeLogradouro() {
        return nomeLogradouro;
    }

    public void setNomeLogradouro(String nomeLogradouro) {
        this.nomeLogradouro = nomeLogradouro;
    }

    public int getNumeroLogradouro() {
        return numeroLogradouro;
    }

    public void setNumeroLogradouro(int numeroLogradouro) {
        this.numeroLogradouro = numeroLogradouro;
    }

    public ESTADO getEstado() {
        return estado;
    }

    public void setEstado(ESTADO estado) {
        this.estado = estado;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getComplemento() {
        return complemento;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    @Override
    public String toString() {
        return "\n\n======= Endereco ========" +
                "\nCEP: " + cep +
                "\nLogradouro: " + nomeLogradouro +
                "\nNumero do Logradouro: " + numeroLogradouro +
                "\nEstado: " + estado +
                "\nCidade: " + cidade +
                "\nBairro: " + bairro +
                "\nComplemento: " + complemento+"\n" ;
    }
    public void addEndereco(){
        Scanner scanner = new Scanner(System.in);
        String regex_cep = "^\\d{5}-?\\d{3}$";
        String regex_logradouro = "^[\\p{L}0-9'\\-\\.\\s]+$";
        String regex_cidadeEbairro = "^[A-Za-zÀ-ÖØ-öø-ÿ\\-\\s']+$";
        while (true){
        System.out.println("Digite o cep");
        cep = scanner.nextLine();
        if(cep.matches(regex_cep)){
            break;}
        else{
            System.out.println("Digite um CEP válido");
        }
        }
        while(true) {
            System.out.println("Digite o Logradouro");
            nomeLogradouro = scanner.nextLine();
        if (nomeLogradouro.matches(regex_logradouro)){
            break;  }
        }
        while(true){
        System.out.println("Digite o Número");
        String numero = scanner.nextLine();
        if (isNumeric(numero)){
            numeroLogradouro = Integer.parseInt(numero);
            break;
        }
        }

        while(true){
        System.out.println("Digite seu Estado");
        String UF =  scanner.nextLine().toUpperCase();
        if (ESTADO.eh_valido(UF)) {
                estado = ESTADO.valueOf(UF);
                break;
            } else {
                System.out.println("Estado inválido, tente novamente.");
            }}
        while(true) {
            System.out.println("Digite sua cidade");
            cidade = scanner.nextLine();
        if (cidade.matches(regex_cidadeEbairro)){
            break;
        }
        }
        while(true){
        System.out.println("Digite seu bairro");
        bairro = scanner.nextLine();
        if (bairro.matches(regex_cidadeEbairro)){
            break;
        }}
        System.out.println("Digite um complemento (opcional)");
        complemento = scanner.nextLine();
        if (complemento == ""){
            complemento = "s/c";
        }
    }
    public String formatarEndereco() {
        return new StringBuilder().append(getNomeLogradouro()).append(", ").append(getNumeroLogradouro()).append(", ")
                .append(getComplemento()).append(" - ").append(getBairro()).append("\nCEP.:").append(getCep())
                .append(" - ").append(getCidade()).append(" ").append(getEstado()).toString();
    }
    public void visualizarEndereco(){
        System.out.println(formatarEndereco());
    }
    public static boolean isNumeric(String str) {
        if (str == null || str.isEmpty()) {
            return false;
        }
        for (char c : str.toCharArray()) {
            if (!Character.isDigit(c)) {
                return false;
            }
        }
        return true;
    }
}
