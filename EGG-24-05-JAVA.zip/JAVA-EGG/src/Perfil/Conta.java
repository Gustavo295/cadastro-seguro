package Perfil;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public class Conta extends Usuario{
    private String email;
    private String senha;
    private String nickname;
    private String telefone;
    private ArrayList<Endereco> enderecos ;
    private int n_endereco;


    public Conta() {
        this.enderecos = new ArrayList<>();

    }

    public Conta(String cpf, String username, LocalDate dataNascimento,
                 String sexo, String email, String senha, String nickname,
                 String telefone, ArrayList<Endereco> enderecos) {
        super(cpf, username, dataNascimento, sexo);
        this.email = email;
        this.senha = senha;
        this.nickname = nickname;
        this.telefone = telefone;
        this.enderecos = enderecos; // inicializando com o ArrayList passado como argumento
    }

    public ArrayList<Endereco> getEnderecos() {
        return enderecos;
    }

    public void setEnderecos(ArrayList<Endereco> enderecos) {
        this.enderecos = enderecos;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    @Override
    public String toString() {
        StringBuilder enderecosFormatados = new StringBuilder();
        for (Endereco endereco : enderecos) {
            n_endereco+=1;
            enderecosFormatados.append("Endereço "+n_endereco+": ").append(endereco.formatarEndereco()).append("\n");
        }
        return "\n\n===== Informações da Conta =====" +
                "\nE-mail: " + email +
                "\nSenha: " + senha +
                "\nNickname: " + nickname +
                "\nTelefone: " + telefone +
                "\n=========== Endereços ===========\n"+
                enderecosFormatados.toString() +
                super.toString();
    }



    public void addConta(){
        Scanner scan = new Scanner(System.in);
        System.out.println("Digite o seu Nome Completo ");
        username = scan.nextLine();
        System.out.println("Digite o seu cpf");
        cpf = scan.nextLine();
        System.out.println("Digite sua data de nascimento");
        dataNascimento = LocalDate.parse(scan.nextLine());
        System.out.println("Digite o seu sexo");
        sexo = scan.nextLine();
        System.out.println("Digite um email");
        email = scan.nextLine();
        System.out.println("Digite uma senha");
        senha = scan.nextLine();
        System.out.println("Digite um nickname");
        nickname = scan.nextLine();
        System.out.println("Digite um telefone para contato");
        telefone = scan.nextLine();
    }
    public void visualizarConta(){
        System.out.println(toString());
    }
    public void excluirConta(){

    }
    public void adicionarEndereco(Endereco endereco){
        this.enderecos.add(endereco);
    }
}
