package Perfil;

import java.time.LocalDate;
import java.util.Date;

public class Assinatura {
    private double preco;
    private PERIODO renovacao;
    private LocalDate dataValidade;
    private LocalDate dataInicio;
    private String beneficios;

    public Assinatura() {
    }

    public Assinatura(double preco, PERIODO renovacao, LocalDate dataValidade, LocalDate dataInicio, String beneficios) {
        this.preco = preco;
        this.renovacao = renovacao;
        this.dataValidade = dataValidade;
        this.dataInicio = dataInicio;
        this.beneficios = beneficios;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public PERIODO getRenovacao() {
        return renovacao;
    }

    public void setRenovacao(PERIODO renovacao) {
        this.renovacao = renovacao;
    }

    public LocalDate getDataValidade() {
        return dataValidade;
    }

    public void setDataValidade(LocalDate dataValidade) {
        this.dataValidade = dataValidade;
    }

    public LocalDate getDataInicio() {
        return dataInicio;
    }

    public void setDataInicio(LocalDate dataInicio) {
        this.dataInicio = dataInicio;
    }

    public String getBeneficios() {
        return beneficios;
    }

    public void setBeneficios(String beneficios) {
        this.beneficios = beneficios;
    }

    @Override
    public String toString() {
        return "\n\n========= Assinatura =========" +
                "\nPreço: " + preco +
                "\nRenovação: " + renovacao +
                "\nData de Validade: " + dataValidade +
                "\nData de Inicio: " + dataInicio +
                "\nBeneficios: " + beneficios ;
    }

    public void renovarAssinatura(){}
    public void cancelarAssinatura(){}
    public void fazerAssinatura(){}
    public void verBeneficios(){}

}
