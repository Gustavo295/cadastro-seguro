import Laudo.*;
import Perfil.*;
import Veiculos.Carro;
import Veiculos.Veiculo;

import javax.tools.Diagnostic;
import java.time.LocalDate;
import java.util.ArrayList;

import static Veiculos.TIPO_CARRO.SUV;


public class Main {
    public static void main(String[] args) {
        var veiculo = new Veiculo("FIAT",1900,
                "Palio","ABC-1234",11.1,"Usado");
        var carro = new Carro("FIAT",1900,
                "Palio","ABC-1234",
                11.1,"Usado","Diesel",
                11,SUV,veiculo);
        System.out.println(carro);
        var veiculoseguro = new VeiculoSegurado(
                veiculo.toString(),
                "Sem informações",
                "Total");
        System.out.println(veiculoseguro);
        var seguro = new Seguro("422.443.332-34","Carlinhos",
                LocalDate.of(2023,12,12),"Masculino",19112,"Total",
                11.1,LocalDate.of(2021,11,11),LocalDate.of(2023,11,11),veiculoseguro);
        System.out.println(seguro);
        var assinatura = new Assinatura(10,PERIODO.ANUAL,
                LocalDate.of(2021,12,12),LocalDate.of(2024,12,12),"n/a");
        System.out.println(assinatura);
        var usuario = new Usuario("422.443.332-34","Carlinhos",
                LocalDate.of(2023,12,12),"Masculino");
        System.out.println(usuario);
        var diagnostico = new Diagnostico(TIPO_PROBLEMA.MECANICO,"Bateria Acabou","Chupetinha","Comprar bateria nova");
        System.out.println(diagnostico);
        var pecas = new Pecas(12,12,2);
        ArrayList<Pecas> listapecas = new ArrayList<>();
        System.out.println(pecas);
        var servicos = new Servicos("",12);
        ArrayList<Servicos> listaservicos = new ArrayList<>();
        System.out.println(servicos);
        var orcamento = new Orcamento(listapecas,listaservicos,
                LocalDate.of(2021,1,1),10);
        System.out.println(orcamento);
        var laudo = new Laudo("LAUDO MECÂNICO",11121,LocalDate.of(2024,05,24),
                usuario,diagnostico,
                orcamento,"Eu por meio deste declaro a veracidade das informações aprensentadas");
        System.out.println(laudo);

//        var endereco = new Endereco();
//        endereco.addEndereco();
//        var endereco2 = new Endereco();
//        endereco2.addEndereco();
//        endereco.visualizarEndereco();
//        var conta = new Conta();
//        conta.addConta();
//        conta.adicionarEndereco(endereco);
//        conta.adicionarEndereco(endereco2);
//        conta.visualizarConta();

    }
}